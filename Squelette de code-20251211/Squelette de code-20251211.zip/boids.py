import sys
import sdl2
import sdl2.ext
import random

def draw_point(renderer, x, y):
    sdl2.SDL_RenderDrawPoint(renderer, x, y)


def main():
    width = 600
    height = 800

    '''
    SDL Initialisation.
    Proceed with care while modifying
    '''
    sdl2.SDL_Init(sdl2.SDL_INIT_VIDEO) # Initialize module
    window = sdl2.SDL_CreateWindow(    # Create the window where the simulation take place
        b"Boids Simulation",           # Name of the window
        sdl2.SDL_WINDOWPOS_CENTERED,   # Position of the window
        sdl2.SDL_WINDOWPOS_CENTERED,
        width, height,                 # Size of the window (pixel)
        sdl2.SDL_WINDOW_SHOWN
    )

    # The renderer is the object use to "draw" on the window
    renderer = sdl2.SDL_CreateRenderer(window, -1, sdl2.SDL_RENDERER_ACCELERATED)
    running = True                     # For the event loop
    event = sdl2.SDL_Event()           # Generic event for interaction

    while running:
        '''
        This is the main event loop for the animation.
        It consists in an infinite while loop, each iteration representing a single frame (or single image)
        Typical animations or games have 60 frames per seconds.
        You will add most of your code / functions here.
        It already contains code to draw a point randomly on the canvas.
        '''

        # This loop lets you quit the window by clicking on the cross
        while sdl2.SDL_PollEvent(event):
            if event.type == sdl2.SDL_QUIT:
                running = False
        
        # Draw a black canvas
        sdl2.SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255)
        sdl2.SDL_RenderClear(renderer)

        # Set renderer tow hite and draw a random point
        sdl2.SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255)
        draw_point(renderer, random.randint(0,width), random.randint(0,height))
        sdl2.SDL_RenderPresent(renderer)

    # Cleanup: we destroy the renderer and window    
    sdl2.SDL_DestroyRenderer(renderer)
    sdl2.SDL_DestroyWindow(window)
    sdl2.SDL_Quit()
    return 0


if __name__ == "__main__":
    sys.exit(main())