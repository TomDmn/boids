#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>

#include <SDL2/SDL.h>

void draw_point(SDL_Renderer *renderer, int x, int y) {
    SDL_RenderDrawPoint(renderer, x, y);
}

int main(int argc, char *argv[]) {
    (void)argc;
    (void)argv;

    const int width  = 600;
    const int height = 800;

    // Initialisation du générateur aléatoire
    srand((unsigned int)time(NULL));

    /*
     * SDL Initialisation.
     * Proceed with care while modifying.
     */
    if (SDL_Init(SDL_INIT_VIDEO) != 0) { // Initialize module
        fprintf(stderr, "Erreur SDL_Init: %s\n", SDL_GetError());
        return 1;
    }
    SDL_Window *window = SDL_CreateWindow( // Create the window where the simulation take place
        "Boids Simulation",                // Name of the window      
        SDL_WINDOWPOS_CENTERED,            // Position of the window
        SDL_WINDOWPOS_CENTERED,            // 
        width, height,                     // Size of the window (pixel)
        SDL_WINDOW_SHOWN
    );
    if (!window) {
        fprintf(stderr, "Erreur SDL_CreateWindow: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }

    // The renderer is the object use to "draw" on the window
    SDL_Renderer *renderer = SDL_CreateRenderer(
        window,
        -1,
        SDL_RENDERER_ACCELERATED
    );
    if (!renderer) {
        fprintf(stderr, "Erreur SDL_CreateRenderer: %s\n", SDL_GetError());
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }

    bool running = true;        // For the event loop
    SDL_Event event;            // Generic event for interaction (clavier, souris, fermeture, ...)

    while (running) {
        /*
        * This is the main event loop for the animation.
        *  It consists in an infinite while loop, each iteration representing a single frame (or single image)
        * Typical animations or games have 60 frames per seconds.
        * You will add most of your code / functions here.
        * It already contains code to draw a point randomly on the canvas.
        */

        // This loop lets you quit the window by clicking on the cross
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                running = false;
            }
        }

        // Draw a black canvas
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);

        // Set renderer tow hite and draw a random point
        SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
        int x = rand() % width;
        int y = rand() % height;
        draw_point(renderer, x, y);

        // Display Frame
        SDL_RenderPresent(renderer);

        // Optionnal: Delay
        // SDL_Delay(16); // ~60 FPS
    }

    // Cleanup
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}
